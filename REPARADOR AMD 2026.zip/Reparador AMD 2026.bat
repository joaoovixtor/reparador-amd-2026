@echo off
:: Reparador AMD Generico 2026 - Compativel com TODOS os processadores e placas-mae AMD
:: Funciona com: Ryzen 3/5/7/9, EPYC e chipsets X370/B350/X470/B450/X570/B550/X670/B650
:: SÓ PARA AMD - Sem Intel, sem outras marcas

setlocal enabledelayedexpansion

:: Pedir permissao de administrador se nao estiver rodando como admin
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' neq '0' (
    echo.
    echo Este script requer permissoes de administrador!
    echo Solicitando acesso...
    echo.
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    set params = %*:"="
    echo UAC.ShellExecute "cmd.exe", "/c cd /d ""%cd%"" && ""%~s0"" %params%", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    del "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
cls
echo.
echo ===================================================================
echo         REPARADOR AMD GENERICO 2026 - COMPATIVEL COM TODOS
echo ===================================================================
echo.
echo Este script funciona com:
echo - Processadores: Ryzen 3/5/7/9, Threadripper, EPYC
echo - Chipsets: X370, B350, X470, B450, X570, B550, X670, B650
echo - Placas-mae de qualquer fabricante com chipset AMD
echo.
echo Iniciando manutencao e reparacao do sistema AMD...
echo.

echo [1/9] Identificando Hardware AMD Instalado...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Processador(es):' -ForegroundColor Cyan; Get-CimInstance Win32_Processor | Select-Object Name,DriverVersion,MaxClockSpeed | Format-Table -AutoSize"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Placa de Video(s):' -ForegroundColor Cyan; Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,DriverDate | Format-Table -AutoSize"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Placa-Mae:' -ForegroundColor Cyan; Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer,Product,Version | Format-Table -AutoSize"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Memoria RAM:' -ForegroundColor Cyan; Get-CimInstance Win32_PhysicalMemory | Select-Object Manufacturer,PartNumber,Capacity | Format-Table -AutoSize"
echo.

echo [2/9] Atualizando Provedor de Pacotes e Modulos...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Install-PackageProvider NuGet -Force -ErrorAction SilentlyContinue" 2>nul
echo Provedor NuGet atualizado
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Install-Module PSWindowsUpdate -Force -AllowClobber -ErrorAction SilentlyContinue" 2>nul
echo Modulo PSWindowsUpdate instalado
echo.

echo [3/9] Atualizando Windows Updates e Drivers...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Import-Module PSWindowsUpdate -ErrorAction SilentlyContinue; Add-WUServiceManager -MicrosoftUpdate -Confirm:$false -ErrorAction SilentlyContinue; Install-WindowsUpdate -MicrosoftUpdate -AcceptAll -IgnoreReboot -ErrorAction SilentlyContinue" 2>nul
echo Windows Update e drivers atualizados
echo.

echo [4/9] Procurando Atualizacoes de Aplicativos...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "winget source update" 2>nul
echo Fontes do Winget atualizadas
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "winget upgrade --all --include-unknown --accept-source-agreements --accept-package-agreements" 2>nul
echo Aplicativos atualizados
echo.

echo [5/9] Verificando e Listando Drivers AMD/Suporte...
echo -------------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Drivers AMD e de Suporte Detectados:' -ForegroundColor Yellow; Get-CimInstance Win32_PnPSignedDriver | Where-Object {$_.Manufacturer -match 'AMD|Advanced Micro Devices|ASUSTeK|ASUS|Realtek|NVIDIA'} | Select-Object DeviceName,Manufacturer,DriverVersion,DriverDate | Format-Table -AutoSize"
echo.

echo [6/9] Verificando Saude da Imagem do Windows...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /ScanHealth
echo.

echo [7/9] Reparando Componentes do Windows...
echo -------------------------------------------------------
DISM /Online /Cleanup-Image /RestoreHealth
echo.

echo [8/9] Verificando Integridade dos Arquivos do Sistema...
echo -------------------------------------------------------
sfc /scannow
echo.

echo [9/9] Verificando Disco e Sistema de Arquivos...
echo -------------------------------------------------------
chkdsk C: /scan
echo.

echo.
echo ===================================================================
echo              REPARACAO E MANUTENCAO CONCLUIDAS COM SUCESSO
echo ===================================================================
echo.
echo Proximas Recomendacoes:
echo - Reinicie o computador para aplicar todas as mudancas
echo - Atualize drivers AMD diretamente do site AMD.com se necessario
echo - Mantenha o Windows Update sempre ativo
echo.
echo ===================================================================
echo.
pause
